

fun main() {

    //   print("Digite seu nome:")
    //  var nome = readLine()
//
    //  if(nome == "Carla")
    //      println("Você é a $nome")
    //  else if(nome == "Natasha")
    //      println("Você é $nome")
    //  else if(nome == "Bianca")
    //       println("Você é $nome")
    //   else
    //       println("Nome inválido")


    println("Digite a média do aluno")
    var media = 15

    if (media >= 6)
        println("Aprovado!")
    if(media >= 2)
        println("Precisa fazer exame!")
    if(media < 2)
        println("Reprovado!")
}