fun main(){
    val nome = "maria"
    val saudacao = "Seja bem vinda "
    println("Ola $nome, ${saudacao +nome}")

    var a  = 5
    var b = 10

    print("A soma de $a + $b = ${a + b}")
}