fun main(){
    var num = 5
    println(podeRetornarNulo(num))

    var qualquerCoisa: Int?
    qualquerCoisa = podeRetornarNulo(num)

    println(qualquerCoisa)
}

fun podeRetornarNulo(a: Int): Int? {
    if (a<5) return 10 else return null
}