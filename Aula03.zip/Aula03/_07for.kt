class _07for {
}